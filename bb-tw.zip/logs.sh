#!/bin/bash
cd /root/bb-tw-alert/nodejs
docker-compose logs --tail=100 -f